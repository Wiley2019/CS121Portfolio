package linkedListActivity;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create two instances of PropertyListing
        PropertyListing property1 = new PropertyListing("123 Elm St", 250000, "Single Family Home");
        PropertyListing property2 = new PropertyListing("456 Oak Ave", 350000, "Condo");

        // Adding viewings for property 1
        System.out.println("Adding viewings for Property 1:");
        for (int i = 0; i < 3; i++) {
            System.out.print("Enter viewing appointment (date and time): ");
            String appointment = scanner.nextLine();
            property1.addViewing(appointment);
        }

        // Adding viewings for property 2
        System.out.println("\nAdding viewings for Property 2:");
        for (int i = 0; i < 3; i++) {
            System.out.print("Enter viewing appointment (date and time): ");
            String appointment = scanner.nextLine();
            property2.addViewing(appointment);
        }

        // Print property information
        System.out.println("\nProperty Information:");
        System.out.println(property1.getPropertyInfo());
        System.out.println(property2.getPropertyInfo());

        // Remove one viewing from each listing
        property1.removeViewing();
        property2.removeViewing();

        // Display the updated viewing history for each property
        System.out.println("\nUpdated Viewing History:");
        property1.displayViewingHistory();
        property2.displayViewingHistory();

        // Editing property information
        System.out.println("\nEdit Property 1 Information:");
        System.out.print("Enter new address: ");
        property1.setAddress(scanner.nextLine());
        System.out.print("Enter new price: ");
        property1.setPrice(scanner.nextDouble());
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new property type: ");
        property1.setPropertyType(scanner.nextLine());

        System.out.println("\nUpdated Property 1 Information:");
        System.out.println(property1.getPropertyInfo());

        scanner.close();
    }
}
