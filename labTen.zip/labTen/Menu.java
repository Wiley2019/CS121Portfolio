package labTen;

import java.util.Scanner;

public class Menu {
    private Scanner scanner;
    private Pokedex pokedex;

    // Constructor
    public Menu() {
        scanner = new Scanner(System.in);
        pokedex = new Pokedex();
    }

    // Display the menu and handle user input
    public void displayMenu() {
        while (true) {
            System.out.println("1: Create Pokemon");
            System.out.println("2: Delete Pokemon");
            System.out.println("3: Display Pokemon");
            System.out.println("4: Display All Pokemon");
            System.out.println("5: Exit");
            System.out.print("Please select an option: ");

            String input = scanner.nextLine();
            if (input.equals("1")) {
                createPokemon();
            } else if (input.equals("2")) {
                deletePokemon();
            } else if (input.equals("3")) {
                displayPokemon();
            } else if (input.equals("4")) {
                displayAllPokemon();
            } else if (input.equals("5")) {
                break;
            } else {
                System.out.println("Invalid entry, please try again.");
            }
        }
    }

    // Create a new Pokémon
    private void createPokemon() {
        System.out.print("Enter Pokemon name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Pokemon HP: ");
        int hp = Integer.parseInt(scanner.nextLine());

        Pokemon pokemon = new Pokemon(name, hp);

        // Add Moves to the Pokemon
        while (true) {
            System.out.print("Enter a move name or 'q' to quit: ");
            String moveName = scanner.nextLine();
            if (moveName.equalsIgnoreCase("q")) {
                break;
            }

            System.out.print("Enter move power: ");
            int power = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter move speed: ");
            int speed = Integer.parseInt(scanner.nextLine());

            Move move = new Move(moveName, power, speed);
            pokemon.addMove(move);
        }

        // Add Pokémon to Pokedex
        pokedex.addPokemon(pokemon);
        System.out.println("Pokemon " + name + " added to Pokedex.");
    }

    // Delete a Pokémon
    private void deletePokemon() {
        System.out.print("Enter the name of the Pokemon to delete: ");
        String name = scanner.nextLine();

        if (pokedex.removePokemon(name)) {
            System.out.println("Pokemon " + name + " has been deleted.");
        } else {
            System.out.println("Pokemon not found.");
        }
    }

    // Display a Pokémon's information
    private void displayPokemon() {
        System.out.print("Enter the name of the Pokemon to display: ");
        String name = scanner.nextLine();

        Pokemon pokemon = pokedex.getPokemon(name);
        if (pokemon != null) {
            System.out.println(pokemon.displayInfo());
        } else {
            System.out.println("Pokemon not found.");
        }
    }

    // Display all Pokémon
    private void displayAllPokemon() {
        System.out.println("All Pokemon in Pokedex:");
        for (Pokemon pokemon : pokedex.getAllPokemon()) {
            System.out.println(pokemon.displayInfo());
        }
    }
}
