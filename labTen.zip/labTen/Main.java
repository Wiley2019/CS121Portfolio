package labTen;

public class Main {
    public static void main(String[] args) {
        // Create an instance of the Menu class and call displayMenu
        Menu menu = new Menu();
        menu.displayMenu();
    }
}
