package weekTen.labTen;

public interface Fighter {
    void attack(Character opponent);
    void defend(int damage);
}