import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Menu {

    private Pokedex pokedex;
    private Scanner scanner;

    public Menu() {
        pokedex = new Pokedex();
        scanner = new Scanner(System.in);
    }

    // Method to create a Pokémon
    public void createPokemon() {
        System.out.println("Choose an option:");
        System.out.println("1. Enter Pokémon details manually");
        System.out.println("2. Select Pokémon from a file");

        int choice = Integer.parseInt(scanner.nextLine());

        if (choice == 1) {
            // Manual entry
            System.out.print("Enter Pokémon name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Pokémon HP: ");
            int hp = Integer.parseInt(scanner.nextLine());

            Pokemon pokemon = new Pokemon(name, hp);
            addMovesToPokemon(pokemon); // Add moves to Pokémon
            pokedex.addPokemon(pokemon); // Add Pokémon to the Pokedex
            System.out.println("Pokémon " + name + " has been successfully added.");

        } else if (choice == 2) {
            // File selection
            FileRead fileReader = new FileRead();
            ArrayList<String[]> pokemonData;

            try {
                pokemonData = fileReader.readPokemonData("CharacterStatsFile.txt");

                if (pokemonData.isEmpty()) {
                    System.out.println("No Pokémon data available in file.");
                    return;
                }

                // Display Pokémon names from the file with numbered choices
                System.out.println("Select a Pokémon from the list:");
                for (int i = 0; i < pokemonData.size(); i++) {
                    System.out.println((i + 1) + ". " + pokemonData.get(i)[0]); // Display Pokémon name
                }

                // Prompt the user to select a Pokémon
                System.out.print("Enter the number of the Pokémon to select: ");
                int selectedIndex = Integer.parseInt(scanner.nextLine()) - 1;

                if (selectedIndex >= 0 && selectedIndex < pokemonData.size()) {
                    String[] selectedPokemon = pokemonData.get(selectedIndex);

                    String pokemonName = selectedPokemon[0];
                    int pokemonHp = Integer.parseInt(selectedPokemon[1]);
                    Pokemon pokemon = new Pokemon(pokemonName, pokemonHp);

                    // Add moves for the Pokémon
                    for (int i = 2; i < selectedPokemon.length; i += 3) {
                        String moveName = selectedPokemon[i];
                        int movePower = Integer.parseInt(selectedPokemon[i + 1]);
                        int moveSpeed = Integer.parseInt(selectedPokemon[i + 2]);

                        Move move = new Move(moveName, movePower, moveSpeed);
                        pokemon.addMove(move);
                    }

                    pokedex.addPokemon(pokemon);
                    System.out.println("Pokémon " + pokemonName + " has been successfully added from file.");
                } else {
                    System.out.println("Invalid selection. Please try again.");
                }

            } catch (FileNotFoundException e) {
                System.out.println("Error: Pokémon data file not found.");
            }
        } else {
            System.out.println("Invalid option. Please try again.");
        }
    }

    // Method to allow users to add multiple moves to a Pokémon manually
    private void addMovesToPokemon(Pokemon pokemon) {
        System.out.println("You can now add moves to Pokémon " + pokemon.getName() + ".");

        while (true) {
            System.out.print("Enter move name (or 'q' to finish): ");
            String moveName = scanner.nextLine();

            if (moveName.equalsIgnoreCase("q")) {
                break;
            }

            System.out.print("Enter move power: ");
            int movePower = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter move speed: ");
            int moveSpeed = Integer.parseInt(scanner.nextLine());

            Move move = new Move(moveName, movePower, moveSpeed);
            pokemon.addMove(move);
        }
    }

    // Method to display all Pokémon in the Pokedex with their moves
    public void displayAllPokemon() {
        ArrayList<Pokemon> allPokemon = pokedex.getAllPokemon();

        if (allPokemon.isEmpty()) {
            System.out.println("No Pokémon are in the Pokedex.");
            return;
        }

        for (Pokemon pokemon : allPokemon) {
            System.out.println("Name: " + pokemon.getName() + ", HP: " + pokemon.getHp());

            ArrayList<Move> moves = pokemon.getMoveArrayList();
            if (moves.isEmpty()) {
                System.out.println("  No moves for this Pokémon.");
            } else {
                for (Move move : moves) {
                    System.out.println("  Move: " + move.getName() + ", Power: " + move.getPower() + ", Speed: " + move.getSpeed());
                }
            }
        }
    }
}
